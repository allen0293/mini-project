 <!-- offcanvas -->
 <div
      class="offcanvas offcanvas-start sidebar-nav bg-success"
      tabindex="-1"
      id="sidebar"
    >
      <div class="offcanvas-body p-0">
        <nav class="navbar-dark">
          <ul class="navbar-nav">
            <li>
              <div class="text-muted small fw-bold text-uppercase px-3">
        
              </div>
            </li>
            <li>
              <a href="dashboard.php" class="nav-link px-3 active">
                <span class="me-2"><i class="bi bi-speedometer2"></i></span>
                <span>Dashboard</span>
              </a>
            </li>
            <li class="my-4"><hr class="dropdown-divider bg-light" /></li>
            <li>
              <div class="text-light small fw-bold text-uppercase px-3 mb-3">
                Interface
              </div>
            </li>
            <li>
             <a class="nav-link px-3 sidebar-link"href="expenses.php">
                <span class="me-2"></i></span>
                <span>Expenses</span>
                <span class="ms-auto">
                  <span class="right-icon"></span>
                </span>
              </a>
            </li>
            <li>
             <a class="nav-link px-3 sidebar-link"href="sales.php">
                <span class="me-2"></i></span>
                <span>Sales</span>
                <span class="ms-auto">
                  <span class="right-icon"></span>
                </span>
              </a>
            </li>
            <li>
            <a class="nav-link px-3 sidebar-link"href="crop.php">
                <span class="me-2"></i></span>
                <span>Croping</span>
                <span class="ms-auto">
                  <span class="right-icon"></span>
                </span>
              </a>
            </li>
            <li>
            <a class="nav-link px-3 sidebar-link"href="profit.php">
                <span class="me-2"></i></span>
                <span>All Records</span>
                <span class="ms-auto">
                  <span class="right-icon"></span>
                </span>
              </a>
            </li>
          </ul>
        </nav>
      </div>
    </div>
    <!-- offcanvas -->